const uint8_t FirmwareVer[3] = { 0, 0, 3 };
	
//LCD I2C
uint8_t copyright1[8] = { 0x03, 0x04, 0x09, 0x0a, 0x0a, 0x09, 0x04, 0x03 }; // copyright Ư�� ���� HEX data
uint8_t copyright2[8] = { 0x18, 0x04, 0x12, 0x02, 0x02, 0x12, 0x04, 0x18 };
uint8_t cursorICon[8] = { 0x02, 0x06, 0x0E, 0x1E, 0x1E, 0x0E, 0x06, 0x02 }; // Ŀ�� ������ HEX data
uint8_t starICon[8] = { 0x00, 0x04, 0x04, 0x1f, 0x0e, 0x1b, 0x11, 0x00 }; // �� ������

//==LCD Menus==========================================================================================================================================================
const char startScreen[][16] = { " DrawingMachine ", "================" };

const char MainMenu[][16] = { "1.StartDrawing", "2.Option", "3.info" };

const char StartDrawingMenu1[][16] = { "Start Drawing?", "1.Yes    2.No" };
const char StartDrawingMenu2[][16] = { "Drawing...", "Press OK to stop" };

const char OptionMenu[][16] = { "1.set Speed", "2.set Angle", "3.set direction", "4.set active" , "5.exit" };
const char OptionMenuSpeed[][16] = { "DrawA: ", "DrawB: ", "TurnC: ", "exit" };
const char OptionMenuAngle[][16] = { "DrawA: ", "DrawB: ", "TurnC: ", "exit" };
const char OptionMenuDir[][16] = { "DrawA: ", "DrawB: ", "TurnC: ", "exit" };
const char OptionMenuActive[][16] = { "DrawA: ", "DrawB: ", "exit" };

const char infoMenu[][16] = { "Version: ", "BetaMan" };

//LCD Menu cursor Positioning
uint8_t cursorPosition = 0;
uint8_t scrollPosition = 0;
boolean returnMain = 0;

//=====================================================================================================================================================================

//Stepper Multi
uint16_t stepPerRevolution[4] = { 400, 400, 400, NULL };
int8_t MAngle[4] = { 0, 0, 0, NULL };
boolean MDir[4] = { 0, 0, 0, NULL };
boolean MActive[3] = { 1, 1, NULL };

//Encoder
int newEnc = 0;
int oldEnc = -999;
const int EncPower = 5;